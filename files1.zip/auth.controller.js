// src/controllers/auth.controller.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const prisma = require('../config/prisma');
const env = require('../config/env');
const { success, unauthorized, badRequest } = require('../utils/apiResponse');
const { asyncHandler } = require('../middleware/errorHandler');

// ── Helper: sign tokens ──────────────────────────────────
const signAccessToken = (user) =>
  jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    env.JWT_SECRET,
    { expiresIn: env.JWT_EXPIRES_IN }
  );

const signRefreshToken = (user) =>
  jwt.sign(
    { id: user.id },
    env.JWT_REFRESH_SECRET,
    { expiresIn: env.JWT_REFRESH_EXPIRES_IN }
  );

// ── Helper: safe user object (no passwordHash) ──────────
const safeUser = (user) => {
  const { passwordHash, ...rest } = user;
  return rest;
};

/**
 * POST /api/auth/login
 */
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  // Find user
  const user = await prisma.user.findUnique({
    where: { email: email.toLowerCase().trim() },
    include: { team: { select: { id: true, teamName: true } } },
  });

  if (!user) {
    return unauthorized(res, 'Invalid email or password');
  }

  if (!user.isActive) {
    return unauthorized(res, 'Your account has been deactivated. Contact your manager.');
  }

  // Verify password
  const passwordMatch = await bcrypt.compare(password, user.passwordHash);
  if (!passwordMatch) {
    return unauthorized(res, 'Invalid email or password');
  }

  const accessToken = signAccessToken(user);
  const refreshToken = signRefreshToken(user);

  return success(res, {
    user: safeUser(user),
    accessToken,
    refreshToken,
  }, 'Login successful');
});

/**
 * GET /api/auth/me
 * Returns the currently authenticated user
 */
const getMe = asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user.id },
    include: {
      team: { select: { id: true, teamName: true } },
    },
  });

  if (!user) {
    return unauthorized(res, 'User not found');
  }

  return success(res, safeUser(user));
});

/**
 * POST /api/auth/refresh
 * Exchange a refresh token for a new access token
 */
const refreshToken = asyncHandler(async (req, res) => {
  const { refreshToken: token } = req.body;

  if (!token) {
    return badRequest(res, 'Refresh token is required');
  }

  let decoded;
  try {
    decoded = jwt.verify(token, env.JWT_REFRESH_SECRET);
  } catch {
    return unauthorized(res, 'Invalid or expired refresh token');
  }

  const user = await prisma.user.findUnique({ where: { id: decoded.id } });
  if (!user || !user.isActive) {
    return unauthorized(res, 'User not found or inactive');
  }

  const accessToken = signAccessToken(user);
  return success(res, { accessToken }, 'Token refreshed');
});

/**
 * POST /api/auth/change-password
 */
const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const userId = req.user.id;

  const user = await prisma.user.findUnique({ where: { id: userId } });

  const match = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!match) {
    return badRequest(res, 'Current password is incorrect');
  }

  const passwordHash = await bcrypt.hash(newPassword, 10);
  await prisma.user.update({ where: { id: userId }, data: { passwordHash } });

  return success(res, null, 'Password changed successfully');
});

module.exports = { login, getMe, refreshToken, changePassword };
