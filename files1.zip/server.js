// src/server.js
const app = require('./app');
const env = require('./config/env');
const prisma = require('./config/prisma');
const logger = require('./utils/logger');
const cron = require('node-cron');

// ─────────────────────────────────────────────────────────
//  Scheduled jobs
// ─────────────────────────────────────────────────────────

/**
 * Runs daily at 8 AM Cairo time (UTC+2 = 06:00 UTC)
 * 1. Expires overdue agreements
 * 2. Creates reminder notifications for agreements expiring in 7 or 14 days
 */
cron.schedule('0 6 * * *', async () => {
  logger.info('⏰  Running daily agreement expiry check...');

  try {
    const now = new Date();
    const in7Days = new Date(now); in7Days.setDate(now.getDate() + 7);
    const in14Days = new Date(now); in14Days.setDate(now.getDate() + 14);

    // 1. Mark past-due active agreements as EXPIRED
    const expired = await prisma.agreement.updateMany({
      where: { status: 'ACTIVE', endDate: { lte: now } },
      data: { status: 'EXPIRED' },
    });
    if (expired.count > 0) {
      logger.info(`  ✅  Expired ${expired.count} agreement(s)`);
    }

    // 2. Build notifications for agreements expiring in 7 days
    const soonAgreements = await prisma.agreement.findMany({
      where: {
        status: 'ACTIVE',
        endDate: { gte: now, lte: in7Days },
      },
      include: { agent: true },
    });

    for (const agr of soonAgreements) {
      // Avoid duplicate notifications
      const exists = await prisma.notification.findFirst({
        where: {
          relatedId: agr.id,
          relatedType: 'agreement',
          type: 'AGREEMENT_EXPIRY',
          createdAt: { gte: new Date(now.toDateString()) },
        },
      });
      if (!exists) {
        await prisma.notification.create({
          data: {
            userId: agr.agentId,
            type: 'AGREEMENT_EXPIRY',
            title: 'Agreement expiring soon',
            body: `Agreement ${agr.agreementCode} expires on ${agr.endDate.toLocaleDateString('en-EG')}`,
            relatedId: agr.id,
            relatedType: 'agreement',
          },
        });
      }
    }

    if (soonAgreements.length > 0) {
      logger.info(`  🔔  Sent ${soonAgreements.length} expiry notification(s)`);
    }
  } catch (err) {
    logger.error('  ❌  Agreement cron error:', err.message);
  }
});

// ─────────────────────────────────────────────────────────
//  Start HTTP server
// ─────────────────────────────────────────────────────────

const server = app.listen(env.PORT, () => {
  logger.info(`🚀  ${env.APP_NAME} API running on port ${env.PORT} [${env.NODE_ENV}]`);
});

// ─────────────────────────────────────────────────────────
//  Graceful shutdown
// ─────────────────────────────────────────────────────────

const shutdown = async (signal) => {
  logger.info(`\n📴  Received ${signal}. Graceful shutdown started...`);
  server.close(async () => {
    await prisma.$disconnect();
    logger.info('✅  Database disconnected. Bye!\n');
    process.exit(0);
  });
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Rejection:', reason);
  shutdown('unhandledRejection');
});
