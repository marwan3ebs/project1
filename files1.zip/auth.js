// src/middleware/auth.js
const jwt = require('jsonwebtoken');
const env = require('../config/env');
const prisma = require('../config/prisma');
const { unauthorized, forbidden } = require('../utils/apiResponse');

/**
 * authenticate — verify JWT and attach req.user
 */
const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return unauthorized(res, 'No token provided');
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, env.JWT_SECRET);

    // Pull fresh user from DB on each request (so deactivated accounts are blocked)
    const user = await prisma.user.findUnique({
      where: { id: decoded.id },
      select: {
        id: true,
        fullName: true,
        email: true,
        role: true,
        teamId: true,
        isActive: true,
      },
    });

    if (!user || !user.isActive) {
      return unauthorized(res, 'Account not found or inactive');
    }

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return unauthorized(res, 'Token expired');
    }
    return unauthorized(res, 'Invalid token');
  }
};

/**
 * authorize — role-based access control
 * Usage: authorize('ADMIN') or authorize('ADMIN', 'TEAM_LEADER')
 */
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) return unauthorized(res);
    if (!roles.includes(req.user.role)) {
      return forbidden(res, 'You do not have permission to perform this action');
    }
    next();
  };
};

/**
 * scopeFilter — attaches a data-scope filter to req based on role:
 *   ADMIN       → no filter (sees everything)
 *   TEAM_LEADER → filter by teamId
 *   AGENT       → filter by agentId (own records only)
 *
 * Controllers read req.scope to build Prisma where-clauses.
 */
const scopeFilter = (req, res, next) => {
  const { role, id, teamId } = req.user;

  if (role === 'ADMIN') {
    req.scope = {}; // no restriction
  } else if (role === 'TEAM_LEADER') {
    req.scope = { teamId }; // filter by team
  } else {
    req.scope = { agentId: id }; // own records only
  }

  next();
};

module.exports = { authenticate, authorize, scopeFilter };
