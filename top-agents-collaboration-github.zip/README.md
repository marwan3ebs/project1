# Top Agents Collaboration

React Native / Expo mobile CRM for RE/MAX Top Agents. It covers primary apartments and resale purchase/rent workflows, agreement tracking, agent scheduling, biweekly manager reports, and team leader performance views.

## Run

```bash
npm install
npm start
```

Use Expo Go on a phone, or press `w` in the Expo terminal for the web preview.

## Main Workflows

- Track primary and resale inventory with customer, agent, location, price, area, source, agreement code, agreement type, and agreement dates.
- Move resale deals through the 10 phases from bringing the unit to closing and commission collection.
- Store buyer purchase agreements and seller open, exclusive, and rent agreements.
- Show agreement expiry reminders based on the 3-month agreement window.
- Schedule meetings, initial previews, follow ups, pricing, contract checks, and signing appointments.
- Produce a biweekly report for agreements signed and deals closed by agent.
- Give team leaders a view of inventory count, exclusive listings, closed deals, targets, and commission.
