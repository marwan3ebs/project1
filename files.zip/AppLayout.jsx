// src/components/layout/AppLayout.jsx
import React, { useState } from 'react';
import { NavLink, useNavigate, Outlet } from 'react-router-dom';
import { clsx } from 'clsx';
import useAuthStore from '../../store/authStore';
import { Avatar } from '../ui';
import { ROLE_LABELS } from '../../utils/helpers';

// Navigation items per role
const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: '📊', roles: ['ADMIN','TEAM_LEADER','AGENT'] },
  { to: '/properties', label: 'Properties', icon: '🏠', roles: ['ADMIN','TEAM_LEADER','AGENT'] },
  { to: '/clients', label: 'Clients', icon: '👥', roles: ['ADMIN','TEAM_LEADER','AGENT'] },
  { to: '/agreements', label: 'Agreements', icon: '📋', roles: ['ADMIN','TEAM_LEADER','AGENT'] },
  { to: '/deals', label: 'Pipeline', icon: '🔄', roles: ['ADMIN','TEAM_LEADER','AGENT'] },
  { to: '/tasks', label: 'Tasks', icon: '✅', roles: ['ADMIN','TEAM_LEADER','AGENT'] },
  { to: '/meetings', label: 'Meetings', icon: '📅', roles: ['ADMIN','TEAM_LEADER','AGENT'] },
  { to: '/marketing', label: 'Marketing', icon: '📢', roles: ['ADMIN','TEAM_LEADER','AGENT'] },
  { to: '/payments', label: 'Payments', icon: '💰', roles: ['ADMIN','TEAM_LEADER','AGENT'] },
  { to: '/reports', label: 'Reports', icon: '📈', roles: ['ADMIN','TEAM_LEADER'] },
  { to: '/users', label: 'Users', icon: '⚙️', roles: ['ADMIN'] },
];

// Bottom nav (mobile — only 4-5 most used items)
const BOTTOM_NAV = [
  { to: '/dashboard', label: 'Home', icon: '📊' },
  { to: '/properties', label: 'Properties', icon: '🏠' },
  { to: '/tasks', label: 'Tasks', icon: '✅' },
  { to: '/deals', label: 'Pipeline', icon: '🔄' },
];

export default function AppLayout() {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const visibleNav = NAV_ITEMS.filter((n) => n.roles.includes(user?.role));

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">

      {/* ── Sidebar overlay (mobile) ─────────────────────── */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* ── Sidebar ──────────────────────────────────────── */}
      <aside className={clsx(
        'fixed inset-y-0 left-0 z-50 w-64 bg-navy-800 flex flex-col transition-transform duration-300 lg:relative lg:translate-x-0',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      )}>
        {/* Logo */}
        <div className="flex items-center gap-2 px-5 h-16 border-b border-navy-700 flex-shrink-0">
          <div className="h-8 w-8 rounded-lg bg-brand-600 flex items-center justify-center text-white text-xs font-bold">TA</div>
          <div className="min-w-0">
            <p className="text-white text-sm font-semibold leading-tight truncate">Top Agents</p>
            <p className="text-navy-300 text-xs truncate">RE/MAX</p>
          </div>
          <button className="ml-auto text-navy-300 lg:hidden" onClick={() => setSidebarOpen(false)}>✕</button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
          {visibleNav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) => clsx(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors',
                isActive
                  ? 'bg-brand-600 text-white font-medium'
                  : 'text-navy-200 hover:bg-navy-700 hover:text-white'
              )}
            >
              <span className="text-base w-5 text-center">{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        {/* User info */}
        <div className="border-t border-navy-700 p-3 flex-shrink-0">
          <div className="flex items-center gap-3 mb-2">
            <Avatar name={user?.fullName} size="sm" />
            <div className="min-w-0 flex-1">
              <p className="text-white text-xs font-medium truncate">{user?.fullName}</p>
              <p className="text-navy-300 text-xs">{ROLE_LABELS[user?.role]}</p>
            </div>
          </div>
          <button onClick={handleLogout} className="w-full text-left text-xs text-navy-300 hover:text-white px-2 py-1.5 rounded hover:bg-navy-700 transition-colors">
            Sign out
          </button>
        </div>
      </aside>

      {/* ── Main area ────────────────────────────────────── */}
      <div className="flex-1 flex flex-col overflow-hidden">

        {/* Top header (mobile) */}
        <header className="lg:hidden flex items-center justify-between h-14 px-4 bg-white border-b border-gray-200 flex-shrink-0 sticky top-0 z-30">
          <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-lg hover:bg-gray-100 text-gray-600">
            <span className="text-xl">☰</span>
          </button>
          <span className="font-semibold text-gray-900 text-sm">Top Agents</span>
          <NavLink to="/notifications" className="p-2 rounded-lg hover:bg-gray-100 text-gray-600 relative">
            <span className="text-xl">🔔</span>
          </NavLink>
        </header>

        {/* Desktop top bar */}
        <header className="hidden lg:flex items-center justify-between h-14 px-6 bg-white border-b border-gray-200 flex-shrink-0">
          <div />
          <div className="flex items-center gap-3">
            <NavLink to="/notifications" className="p-2 rounded-lg hover:bg-gray-100 text-gray-500 text-lg">🔔</NavLink>
            <div className="flex items-center gap-2">
              <Avatar name={user?.fullName} size="sm" />
              <div>
                <p className="text-sm font-medium text-gray-800">{user?.fullName}</p>
                <p className="text-xs text-gray-500">{ROLE_LABELS[user?.role]}</p>
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto pb-20 lg:pb-0">
          <Outlet />
        </main>
      </div>

      {/* ── Bottom navigation (mobile only) ─────────────── */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-white border-t border-gray-200 flex items-stretch safe-area-bottom">
        {BOTTOM_NAV.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => clsx(
              'flex-1 flex flex-col items-center justify-center py-2 gap-0.5 text-xs transition-colors',
              isActive ? 'text-brand-600 font-medium' : 'text-gray-500'
            )}
          >
            <span className="text-xl leading-none">{item.icon}</span>
            <span>{item.label}</span>
          </NavLink>
        ))}
        {/* More menu */}
        <NavLink
          to="/agreements"
          className={({ isActive }) => clsx(
            'flex-1 flex flex-col items-center justify-center py-2 gap-0.5 text-xs transition-colors',
            isActive ? 'text-brand-600 font-medium' : 'text-gray-500'
          )}
        >
          <span className="text-xl leading-none">⋯</span>
          <span>More</span>
        </NavLink>
      </nav>
    </div>
  );
}
