// src/pages/dashboard/AgentDashboard.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import { useApi } from '../../hooks/useApi';
import { dashboardApi } from '../../api';
import { StatCard, PageLoader, Badge } from '../../components/ui';
import { formatCurrency, formatDate, formatDateTime, STAGE_LABELS, STAGE_COLORS, TASK_STATUS_COLORS, daysUntil } from '../../utils/helpers';
import useAuthStore from '../../store/authStore';

export default function AgentDashboard() {
  const { user } = useAuthStore();
  const { data, loading } = useApi(() => dashboardApi.getAgentStats());

  if (loading) return <PageLoader />;
  if (!data) return null;

  const { stats, myExpiringAgreements, myTasksDue, myUpcomingMeetings, myRecentDeals } = data;

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="page">
      <div className="mb-2">
        <h1 className="page-title">{greeting}, {user?.fullName?.split(' ')[0]} 👋</h1>
        <p className="page-subtitle">Here's your day at a glance</p>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 gap-3">
        <StatCard label="My Properties" value={stats.myProperties} icon="🏠" color="brand" />
        <StatCard label="Active Agreements" value={stats.myActiveAgreements} icon="📋" color="blue" />
        <StatCard label="My Deals" value={stats.myDeals} icon="🔄" color="purple" />
        <StatCard label="Closed Deals" value={stats.myClosedDeals} icon="✅" color="green" />
      </div>
      <StatCard label="Total Commission Earned" value={formatCurrency(stats.myCommission)} icon="💰" color="green" />

      {/* Overdue tasks */}
      {(myTasksDue || []).length > 0 && (
        <div className="card border-l-4 border-l-red-500">
          <div className="card-header flex items-center justify-between">
            <h3 className="text-sm font-semibold text-red-700">⚠️ Overdue Tasks ({myTasksDue.length})</h3>
            <Link to="/tasks" className="text-xs text-brand-600">View all</Link>
          </div>
          <div className="divide-y divide-gray-100">
            {myTasksDue.slice(0, 3).map((task) => (
              <div key={task.id} className="px-4 py-3">
                <p className="text-sm font-medium text-gray-800">{task.title}</p>
                <p className="text-xs text-red-600 mt-0.5">Due: {formatDateTime(task.dueDate)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Expiring agreements */}
      {(myExpiringAgreements || []).length > 0 && (
        <div className="card border-l-4 border-l-yellow-400">
          <div className="card-header flex items-center justify-between">
            <h3 className="text-sm font-semibold text-yellow-700">📅 Expiring Agreements</h3>
            <Link to="/agreements" className="text-xs text-brand-600">View all</Link>
          </div>
          <div className="divide-y divide-gray-100">
            {myExpiringAgreements.slice(0, 3).map((agr) => {
              const days = daysUntil(agr.endDate);
              return (
                <Link to={`/agreements/${agr.id}`} key={agr.id} className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{agr.property?.unitCode}</p>
                    <p className="text-xs text-gray-500 truncate">{agr.client?.fullName}</p>
                  </div>
                  <span className={`text-xs font-semibold flex-shrink-0 ${days <= 7 ? 'text-red-600' : 'text-yellow-600'}`}>
                    {days}d left
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      )}

      {/* Upcoming meetings */}
      {(myUpcomingMeetings || []).length > 0 && (
        <div className="card">
          <div className="card-header flex items-center justify-between">
            <h3 className="text-sm font-semibold text-gray-700">📅 Upcoming Meetings</h3>
            <Link to="/meetings" className="text-xs text-brand-600">View all</Link>
          </div>
          <div className="divide-y divide-gray-100">
            {myUpcomingMeetings.slice(0, 3).map((m) => (
              <div key={m.id} className="flex items-center gap-3 px-4 py-3">
                <div className="h-9 w-9 rounded-lg bg-indigo-50 flex items-center justify-center text-lg flex-shrink-0">📅</div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-gray-800 truncate">{m.meetingType?.replace(/_/g,' ')}</p>
                  <p className="text-xs text-gray-500">{formatDateTime(m.scheduledAt)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent deals */}
      <div className="card">
        <div className="card-header flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-700">My Recent Deals</h3>
          <Link to="/deals" className="text-xs text-brand-600">View all</Link>
        </div>
        <div className="divide-y divide-gray-100">
          {(myRecentDeals || []).length === 0 ? (
            <div className="text-center py-8">
              <p className="text-sm text-gray-400">No deals yet</p>
              <Link to="/deals" className="text-xs text-brand-600 mt-1 inline-block">Start a deal →</Link>
            </div>
          ) : (myRecentDeals || []).map((deal) => (
            <Link to={`/deals/${deal.id}`} key={deal.id} className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-800 truncate">{deal.property?.unitCode}</p>
                <p className="text-xs text-gray-500 truncate">{deal.property?.location}</p>
              </div>
              <span className={`badge text-xs ${STAGE_COLORS[deal.pipelineStage] || 'badge-gray'}`}>
                {STAGE_LABELS[deal.pipelineStage] || deal.pipelineStage}
              </span>
            </Link>
          ))}
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 gap-3 pb-4">
        <Link to="/properties/new" className="btn-primary h-12 text-sm">+ Add Property</Link>
        <Link to="/tasks" className="btn-secondary h-12 text-sm">My Tasks</Link>
      </div>
    </div>
  );
}
