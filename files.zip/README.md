# Top Agents Collaboration
## RE/MAX Top Agents — Real Estate CRM

A full-stack, mobile-first PWA for managing real estate agents, properties,
agreements, deals, and commissions.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18 · Vite · Tailwind CSS · React Router v6 · Recharts · Zustand |
| Backend | Node.js · Express.js · Prisma ORM |
| Database | PostgreSQL |
| Auth | JWT (access + refresh tokens) |
| PWA | Service Worker · Web App Manifest · Add to Home Screen |

---

## Project Structure

```
top-agents-collaboration/
  backend/
    prisma/
      schema.prisma        # Full DB schema (13 models)
      seed.js              # Demo data with 4 users
    src/
      controllers/         # auth, users, teams, clients, properties,
      │                    # agreements, deals, tasks, meetings,
      │                    # marketing, contracts, payments,
      │                    # dashboard, reports, notifications
      routes/              # One file per module, all registered in index.js
      middleware/          # auth.js · validate.js · errorHandler.js · upload.js
      utils/               # logger · apiResponse · commissionCalculator
      config/              # env.js · prisma.js
      server.js            # Entry point + daily cron + graceful shutdown
      app.js               # Express setup
  frontend/
    public/
      manifest.json        # PWA manifest
      sw.js                # Service worker (cache-first)
      icons/               # 8 PNG icons (72px → 512px)
    src/
      api/                 # axios.js + all API service functions
      components/
        layout/            # AppLayout · AuthLayout · ProtectedRoute
        ui/                # Shared components (Modal, Badge, StatCard, etc.)
      hooks/               # useApi · useMutation
      pages/               # All 20+ pages
      store/               # authStore (Zustand)
      utils/               # helpers, formatters, constants
```

---

## Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL 14+
- npm or yarn

### 1. Clone and install

```bash
git clone <repo-url>
cd top-agents-collaboration

# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install
```

### 2. Configure backend

```bash
cd backend
cp .env.example .env
# Edit .env — set DATABASE_URL and JWT secrets
```

`.env` minimum:
```
DATABASE_URL="postgresql://USER:PASSWORD@localhost:5432/top_agents_db"
JWT_SECRET=change_this_to_a_long_random_string
JWT_REFRESH_SECRET=another_long_random_string
CLIENT_URL=http://localhost:5173
```

### 3. Database setup

```bash
cd backend

# Run migrations
npx prisma migrate dev --name init

# Generate Prisma client
npx prisma generate

# Seed demo data
node prisma/seed.js
```

### 4. Run development servers

```bash
# Terminal 1 — Backend (port 5000)
cd backend && npm run dev

# Terminal 2 — Frontend (port 5173)
cd frontend && npm run dev
```

Open: **http://localhost:5173**

---

## Demo Credentials

| Role | Email | Password |
|---|---|---|
| Admin / Manager | admin@remax-topagents.com | Admin@1234 |
| Team Leader | leader@remax-topagents.com | Leader@1234 |
| Agent 1 | agent1@remax-topagents.com | Agent@1234 |
| Agent 2 | agent2@remax-topagents.com | Agent@1234 |

---

## PWA — Install on Mobile

1. Open the app in Chrome (Android) or Safari (iOS)
2. Android: tap the browser menu → **"Add to Home Screen"**
3. iOS: tap Share → **"Add to Home Screen"**
4. The app will behave like a native app with offline shell support

---

## User Roles & Permissions

| Feature | Admin | Team Leader | Agent |
|---|---|---|---|
| All data | ✅ | ❌ | ❌ |
| Team data | ✅ | ✅ | ❌ |
| Own data | ✅ | ✅ | ✅ |
| Generate reports | ✅ | Team only | ❌ |
| Manage users | ✅ | ❌ | ❌ |
| Delete records | ✅ | ❌ | ❌ |

---

## Commission Rules

### Purchase
- Buyer side: 2.5% – 3% of sale price
- Seller side: 2.5% – 3% of sale price
- Both sides: double the single-side rate

### Rent
| Duration | Commission |
|---|---|
| < 1 year | 10% of total rent (monthly × months) |
| 1–2 years | 1 month rent |
| 3–4 years | 1.5 months rent |
| 5+ years | 2 months rent |
| High-value | 1 month rent (override) |

---

## Agreement Rules
- All seller agreements are valid for **90 days** from signing date
- `endDate` is **auto-calculated** on creation: `startDate + 90 days`
- **14-day** and **7-day** reminder tasks are auto-created on every agreement
- Daily cron job marks overdue agreements as `EXPIRED` and sends notifications

---

## API Endpoints

All routes are prefixed with `/api`

```
POST   /api/auth/login
GET    /api/auth/me
POST   /api/auth/refresh

GET    /api/users
POST   /api/users
PUT    /api/users/:id
DELETE /api/users/:id

GET    /api/teams
POST   /api/teams
PUT    /api/teams/:id
POST   /api/teams/:id/members

GET    /api/properties
POST   /api/properties
GET    /api/properties/:id
PUT    /api/properties/:id
POST   /api/properties/:id/photos

GET    /api/clients
POST   /api/clients

GET    /api/agreements
POST   /api/agreements
GET    /api/agreements/expiring

GET    /api/deals
POST   /api/deals
PATCH  /api/deals/:id/stage
POST   /api/deals/calculate-commission

GET    /api/tasks
POST   /api/tasks
PATCH  /api/tasks/:id/complete

GET    /api/meetings
POST   /api/meetings

GET    /api/marketing
POST   /api/marketing

GET    /api/payments
POST   /api/payments

GET    /api/dashboard/admin
GET    /api/dashboard/team-leader
GET    /api/dashboard/agent

GET    /api/reports/bi-weekly
GET    /api/reports/pipeline
GET    /api/reports/commissions

GET    /api/notifications
PATCH  /api/notifications/:id/read
PATCH  /api/notifications/read-all
```

---

## Production Build

```bash
# Frontend
cd frontend && npm run build
# Output in frontend/dist/ — deploy to Nginx / Vercel / Netlify

# Backend
cd backend && npm start
# Deploy to Railway / Render / DigitalOcean
```

---

## Environment Variables Reference

### Backend
| Variable | Description |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `JWT_SECRET` | Access token signing key |
| `JWT_EXPIRES_IN` | Access token TTL (default: 7d) |
| `JWT_REFRESH_SECRET` | Refresh token signing key |
| `JWT_REFRESH_EXPIRES_IN` | Refresh token TTL (default: 30d) |
| `PORT` | HTTP port (default: 5000) |
| `CLIENT_URL` | Frontend URL for CORS |
| `UPLOAD_DIR` | Local upload directory |
| `MAX_FILE_SIZE_MB` | Max upload size in MB |

---

## Roadmap — What to add next

- [ ] Push notifications (Web Push API)
- [ ] WhatsApp integration for client follow-ups
- [ ] PDF export for bi-weekly reports
- [ ] Primary apartment developer module
- [ ] Contract e-signing integration
- [ ] Multi-branch / multi-company support
